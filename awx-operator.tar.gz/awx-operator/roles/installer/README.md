AWX
=======

This role builds and maintains an Ansible Tower instance inside of Kubernetes.

Requirements
------------

TODO.

Role Variables
--------------

See `defaults/main.yml` for all the role variables that you can override.

TODO: add variable description table.

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: localhost
      connection: local
      roles:
         - awx

License
-------

MIT / BSD
